# Public website tracking

Updated `roaya-website/src/app/core/services/analytics.service.ts`:
- Existing action calls now queue Google tag commands even when GTM is present.
- Google commands use the official Arguments queue format.
- Hotjar receives event-name markers when its Site ID is configured and recording is accepted.
- Consent and privacy signals are checked before each event; /admin remains excluded.
- Query strings are removed from manual page views and Hotjar state changes. Common contact/search parameter keys are excluded from vendor events.
- GTM remains the pageview owner when its bootstrap is present; verify its History Change trigger before deployment. A GTM bootstrap alone cannot prove its published GA4 tags are configured correctly.

Account observations on October 4, 2026:
- Google Analytics is signed in, but the email-preferences modal prevents property inspection.
- Hotjar requires sign-in.
- Contentsquare project 1060380 has tag `5cc66f91cb916`, matching production configuration. Automatic URL-change tracking and JS error collection are enabled. Session Replay currently displays no replays.

The signed-in Roaya property has web stream 15859369628 for https://roaya.co/ and Measurement ID `G-MPRS7PSDC4`. Production now targets that stream directly with manual application pageviews (`googleAnalyticsUsesGtm: false`); its automatic GA4 history-change pageviews must be disabled before deployment. Legacy GTM remains present and may send data to the older property.

The local changes are not deployed. Generic public button/link clicks emit `website_click` with the control type only (button, email, phone, whatsapp, internal_link, external_link). Existing application form/content events remain supported. Contentsquare's verification returned Tag not found for https://roaya.co/; consent gating may prevent an automated verification from seeing the tag, so this alone does not prove no consented sessions can be recorded. Hotjar Site ID remains empty until account access is available; do not treat the Contentsquare project ID as a Hotjar ID.

GitHub origin discovered in the archive: https://github.com/mohamedatef90/roaya.git. Browser access is signed in. GitHub CLI authentication is expired and a device refresh is pending. Deployment documentation uses VPN/SSH to the self-hosted origin; GitHub push alone is not a verified production deployment mechanism.

Verification: `node roaya/verification/analytics-check.cjs` from the workspace root. This checks service behavior with mocked browser/provider queues; it does not prove delivery to live vendor accounts or replace an Angular production build.

Before release: confirm GTM sends exactly one pageview for initial load and each Angular navigation; inspect GA4 Realtime/DebugView for the existing form/content events; verify recordings only start after recording consent. CTA clicks currently go to the first-party website analytics service; additional GTM click tags or application event wiring are needed to mirror these to GA4.
